#!/bin/bash

npm test
