# 014-Posts
***

## Goal: Fix the broken posts!

*Instructions:*

Something is wrong with the posts. The services section is overlapping with it. Services are supposed to be at the very bottom, underneath the posts. Play with the `app.css` file to remedy this issue.

*Note:*  Don't change the HTML.
