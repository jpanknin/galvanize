# 002-Width
***

## Goal: Adjust the width of HTML elements.

*Instructions:*

Try to replicate the example image provided on the webpage by adding styling in your
`app.css` file using the `width` property.
