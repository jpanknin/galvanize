# 006-Box-Model
***

## Goal: Create a box model.

*Instructions:*

Try to replicate the example image provided on the webpage by adding styling in your
`app.css` file. Make use of the properties you've already learned.
