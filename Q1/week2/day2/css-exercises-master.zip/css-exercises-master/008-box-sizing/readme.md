# 008-Box-Sizing
***

## Goal: Fix the broken boxes so they form one continuous row.

*Instructions:*

Try to replicate the example image provided on the webpage by adding styling in your
`app.css` file using some of the properties you've already learned.
